#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include "header_msg.h"

int main() {

    srand(getpid());


    key_t chiave_connect = ftok(".", 'a');

    int id_connect = msgget(chiave_connect, 0);

    if(id_connect < 0) {
        perror("Errore creazione coda di messaggi");
        exit(1);
    }

    key_t chiave_ack = ftok(".", 'b');

    int id_ack = msgget(chiave_ack, 0);

    if(id_ack < 0) {
        perror("Errore creazione coda di messaggi");
        exit(1);
    }


    messaggio_connect conn;

    conn.type = CONNECT;
    conn.pid = getpid();

    int ret = msgsnd(id_connect, &conn, sizeof(conn)-sizeof(long), 0);

    if(ret < 0) {
        perror("Errore invio messaggio connect");
        exit(1);
    }

    messaggio_ack ack;

    ret = msgrcv(id_ack, &ack, sizeof(ack)-sizeof(long), getpid(), 0);

    if(ret < 0) {
        perror("Errore ricezione messaggio ack");
        exit(1);
    }

    printf("[CLIENT %d] Connesso\n", getpid());

    int id_coda_richieste = ack.id_coda_richieste;

    int id_coda_risposte = ack.id_coda_risposte;


    messaggio_richiesta req;
    messaggio_risposta res;


    for(int i=0; i<3; i++) {

        printf("[CLIENT %d] Invio richiesta produzione\n", getpid());

        int valore = rand() % 10;

        req.type = RICHIESTA_PRODUCI;
        req.valore = valore;

        ret = msgsnd(id_coda_richieste, &req, sizeof(req)-sizeof(long), 0);

        if(ret < 0) {
            perror("Errore invio messaggio richiesta");
            exit(1);
        }



        ret = msgrcv(id_coda_risposte, &res, sizeof(res)-sizeof(long), 0, 0);

        if(ret < 0) {
            perror("Errore ricezione messaggio risposta");
            exit(1);
        }

        printf("[CLIENT %d] Valore prodotto: %d\n", getpid(), valore);

    }


    for(int i=0; i<3; i++) {

        printf("[CLIENT %d] Invio richiesta consumazione\n", getpid());

        req.type = RICHIESTA_CONSUMA;

        ret = msgsnd(id_coda_richieste, &req, sizeof(req)-sizeof(long), 0);

        if(ret < 0) {
            perror("Errore invio messaggio richiesta");
            exit(1);
        }


        ret = msgrcv(id_coda_risposte, &res, sizeof(res)-sizeof(long), 0, 0);

        if(ret < 0) {
            perror("Errore ricezione messaggio risposta");
            exit(1);
        }


        int valore = res.valore;

        printf("[CLIENT %d] Valore consumato: %d\n", getpid(), valore);

    }


    msgctl(id_coda_richieste, IPC_RMID, NULL);
    msgctl(id_coda_risposte, IPC_RMID, NULL);

}