#ifndef _HEADER_MSG_H_
#define _HEADER_MSG_H_

#include <sys/types.h>

#define CONNECT 1
#define RICHIESTA_PRODUCI 2
#define RICHIESTA_CONSUMA 3
#define RISPOSTA_PRODUCI 4
#define RISPOSTA_CONSUMA 5

typedef struct {
    long type;
    pid_t pid;
} messaggio_connect;

typedef struct {
    long type;
    int id_coda_richieste;
    int id_coda_risposte;
} messaggio_ack;

typedef struct {
    long type;
    int valore;
} messaggio_richiesta;

typedef struct {
    long type;
    int valore;
} messaggio_risposta;

#endif