#include "header_monitor.h"

void init_monitorpc(MonitorPC *p) {

    p->testa = 0;
    p->coda = 0;
    p->count = 0;

    pthread_mutex_init(&(p->mutex), NULL);
    pthread_cond_init(&(p->cv_prod), NULL);
    pthread_cond_init(&(p->cv_cons), NULL);
}

void remove_monitorpc(MonitorPC *p) {

    pthread_mutex_destroy(&(p->mutex));
    pthread_cond_destroy(&(p->cv_prod));
    pthread_cond_destroy(&(p->cv_cons));
}

void produci(MonitorPC *p, int val) {

    pthread_mutex_lock(&(p->mutex));

    while(p->count == DIM) {
        pthread_cond_wait(&(p->cv_prod), &(p->mutex));
    }

    p->buffer[p->testa] = val;
    p->testa = (p->testa + 1) % DIM;
    p->count++;

    pthread_cond_signal(&(p->cv_cons));

    pthread_mutex_unlock(&(p->mutex));
}

int consuma(MonitorPC *p) {

    int val;

    pthread_mutex_lock(&(p->mutex));

    while(p->count == 0) {
        pthread_cond_wait(&(p->cv_cons), &(p->mutex));
    }

    val = p->buffer[p->coda];
    p->coda = (p->coda + 1) % DIM;
    p->count--;

    pthread_cond_signal(&(p->cv_prod));

    pthread_mutex_unlock(&(p->mutex));

    return val;
}
