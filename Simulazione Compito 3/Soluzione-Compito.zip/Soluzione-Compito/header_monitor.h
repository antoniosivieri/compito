#ifndef _HEADER_MONITOR_H_
#define _HEADER_MONITOR_H_

#include <pthread.h>

#define DIM 5

typedef struct {

    int buffer[DIM];
    int testa;
    int coda;
    int count;

    pthread_mutex_t mutex;
    pthread_cond_t cv_prod;
    pthread_cond_t cv_cons;

} MonitorPC;

void init_monitorpc(MonitorPC *p);
void remove_monitorpc(MonitorPC *p);
void produci(MonitorPC *p, int val);
int consuma(MonitorPC *p);

#endif