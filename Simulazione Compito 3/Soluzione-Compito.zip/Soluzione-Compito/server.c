#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include "header_msg.h"
#include "header_monitor.h"

typedef struct {
    int id_coda_richieste;
    int id_coda_risposte;
    MonitorPC *p;
    pid_t pid;
} parametri_thread;

void * thread_worker(void *);

int main() {

    srand(getpid());


    key_t chiave_connect = ftok(".", 'a');

    int id_connect = msgget(chiave_connect, 0);

    if(id_connect < 0) {
        perror("Errore creazione coda di messaggi");
        exit(1);
    }

    key_t chiave_ack = ftok(".", 'b');

    int id_ack = msgget(chiave_ack, 0);

    if(id_ack < 0) {
        perror("Errore creazione coda di messaggi");
        exit(1);
    }


    MonitorPC *p = (MonitorPC *) malloc(sizeof(MonitorPC));

    init_monitorpc(p);


    pthread_t worker[2];


    // Ripete per 2 client

    for(int i=0; i<2; i++) {

        messaggio_connect conn;

        int ret = msgrcv(id_connect, &conn, sizeof(conn)-sizeof(long), CONNECT, 0);

        if(ret < 0) {
            perror("Errore ricezione messaggio connect");
            exit(1);
        }

        pid_t pid = conn.pid;



        int id_coda_richieste = msgget(IPC_PRIVATE, IPC_CREAT | 0664);

        if(id_coda_richieste < 0) {
            perror("Errore creazione coda di messaggi");
            exit(1);
        }

        int id_coda_risposte = msgget(IPC_PRIVATE, IPC_CREAT | 0664);

        if(id_coda_risposte < 0) {
            perror("Errore creazione coda di messaggi");
            exit(1);
        }



        messaggio_ack ack;

        ack.type = conn.pid;
        ack.id_coda_richieste = id_coda_richieste;
        ack.id_coda_risposte = id_coda_risposte;

        ret = msgsnd(id_ack, &ack, sizeof(ack)-sizeof(long), 0);

        if(ret < 0) {
            perror("Errore invio messaggio ack");
            exit(1);
        }


        printf("[SERVER] Connesso client %d\n", pid);


        parametri_thread *pt = (parametri_thread *) malloc(sizeof(parametri_thread));

        pt->id_coda_richieste = id_coda_richieste;
        pt->id_coda_risposte = id_coda_risposte;
        pt->p = p;
        pt->pid = pid;

        pthread_create(&worker[i], NULL, thread_worker, (void *) pt);

    }

    for(int i=0; i<2; i++) {
        pthread_join(worker[0], NULL);
    }

    remove_monitorpc(p);

    free(p);

}


void * thread_worker(void * arg) {

    parametri_thread *pt = (parametri_thread *) arg;

    int id_coda_richieste = pt->id_coda_richieste;
    int id_coda_risposte = pt->id_coda_risposte;
    MonitorPC *p = pt->p;
    pid_t pid = pt->pid;


    // Ogni worker serve 6 richieste, e poi termina

    for(int i=0; i<6; i++) {

        printf("[SERVER] In attesa di richiesta dal client %d\n", pid);


        messaggio_richiesta richiesta;

        int ret = msgrcv(id_coda_richieste, &richiesta, sizeof(richiesta)-sizeof(long), 0, 0);

        if(ret < 0) {
            perror("Errore ricezione messaggio richiesta");
            exit(1);
        }


        if(richiesta.type == RICHIESTA_PRODUCI) {

            printf("[SERVER] Richiesta di produzione dal client %d\n", pid);

            int valore = richiesta.valore;

            produci(p, valore);

            printf("[SERVER] Valore prodotto: %d (client %d)\n", valore, pid);


            messaggio_risposta risposta;

            risposta.type = RISPOSTA_PRODUCI;

            ret = msgsnd(id_coda_risposte, &risposta, sizeof(risposta)-sizeof(long), 0);

            if(ret < 0) {
                perror("Errore invio messaggio risposta");
                exit(1);
            }

            printf("[SERVER] Risposta inviata al client %d\n", pid);

        }
        else if(richiesta.type == RICHIESTA_CONSUMA) {

            printf("[SERVER] Richiesta di consumazione dal client %d\n", pid);

            int valore = consuma(p);

            printf("[SERVER] Valore consumato: %d (client %d)\n", valore, pid);


            messaggio_risposta risposta;

            risposta.type = RISPOSTA_CONSUMA;
            risposta.valore = valore;

            ret = msgsnd(id_coda_risposte, &risposta, sizeof(risposta)-sizeof(long), 0);

            if(ret < 0) {
                perror("Errore invio messaggio risposta");
                exit(1);
            }

            printf("[SERVER] Risposta inviata al client %d\n", pid);

        }
    }

    free(pt);

    pthread_exit(NULL);
}