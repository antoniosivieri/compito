#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>

int main() {

    key_t chiave_connect = ftok(".", 'a');

    int id_connect = msgget(chiave_connect, IPC_CREAT | 0664);

    if(id_connect < 0) {
        perror("Errore creazione coda di messaggi");
        exit(1);
    }

    key_t chiave_ack = ftok(".", 'b');

    int id_ack = msgget(chiave_ack, IPC_CREAT | 0664);

    if(id_ack < 0) {
        perror("Errore creazione coda di messaggi");
        exit(1);
    }

        pid_t pid;

        pid = fork();

        if(pid == 0) {
            execl("./server", "server", NULL);
            perror("Errore esecuzione server");
            exit(1);
        }

        for(int i=0; i<2; i++) {
                pid = fork();

                if(pid == 0) {
                        execl("./client", "client", NULL);
                        perror("Errore esecuzione client");
                        exit(1);
                }

        }

        for(int i=0; i<3; i++) {
                wait(NULL);
        }

        msgctl(id_connect, IPC_RMID, NULL);
        msgctl(id_ack, IPC_RMID, NULL);
}